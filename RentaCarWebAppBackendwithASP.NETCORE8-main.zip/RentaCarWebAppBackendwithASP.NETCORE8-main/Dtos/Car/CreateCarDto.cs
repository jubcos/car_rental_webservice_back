﻿namespace CarRental.Dtos.Car
{
    public class CreateCarDto
    {
        public string License { get; set; }
        public int Km { get; set; }
        public int ModelId { get; set; }
    }
}
