﻿namespace CarRental.Dtos.Comment
{
    public class CreateCommentDto
    {
        public string Content { get; set; }
        public int CatalogId { get; set; }
    }
}
